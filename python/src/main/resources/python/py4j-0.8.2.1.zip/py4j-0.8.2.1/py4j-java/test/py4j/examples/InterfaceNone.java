package py4j.examples;

public interface InterfaceNone {
	
	public String getName();

}
