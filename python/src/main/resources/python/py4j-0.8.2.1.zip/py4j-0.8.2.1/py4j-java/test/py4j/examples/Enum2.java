package py4j.examples;

public enum Enum2 {
	BAR, FOO;
}
